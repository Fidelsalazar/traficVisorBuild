(function () {
    BizTrackingA.XdcCallback({
        xdc: ""
    });
})();
;
